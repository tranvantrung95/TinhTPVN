# Nghị định 510/NQ-UBTVQH15
Thành lập thị trấn Phương Sơn thuộc huyện Lục Nam và thị trấn Bắc Lý thuộc huyện Hiệp Hòa, tỉnh Bắc Giang
**Ngày ban hành**: 12/05/2022  
**Ngày có hiệu lực**: 01/07/2022  
Chi tiết xem tại: [510/NQ-UBTVQH15](https://thuvienphapluat.vn/van-ban/Bo-may-hanh-chinh/Nghi-quyet-510-NQ-UBTVQH15-2022-thanh-lap-thi-tran-Phuong-Son-huyen-Luc-Nam-Bac-Giang-516371.aspx)

## Nội dung bản cập nhật
- Cập nhật Phương Sơn và Bắc Lý từ cấp Xã (10) lên Thị trấn (9)

### Hướng dẫn cập nhật
Cập nhật bằng cách chạy trực tiếp tệp patch [510_NQ-UBTVQH15_patch.sql](510_NQ-UBTVQH15_patch.sql)

---
_English_  
Decree 510/NQ-UBTVQH15  
- Change Phương Sơn and Bắc Lý from commune (Xã - 10) to commune-level town (Thị trấn - 9)  

How to run: Execute the patch [510_NQ-UBTVQH15_patch.sql](510_NQ-UBTVQH15_patch.sql) directly   
